import telebot
import random
import time
from telebot import types
from config import BOT_TOKEN, ADMIN_ID, DATABASE_NAME
from database import Database

bot = telebot.TeleBot(BOT_TOKEN)  # Инициализация бота
db = Database(DATABASE_NAME)  # Инициализация базы данных

# Глобальная переменная для хранения текущей игры и ставки
current_game = {}
current_bet = {}

@bot.message_handler(commands=['give'])
def give_money(message):
    if str(message.chat.id) == ADMIN_ID:
        try:
            _, user_id, amount = message.text.split()
            user_id = int(user_id)
            amount = float(amount)
            db.update_balance(user_id, amount)
            bot.reply_to(message, f"Вы дали {amount}$ пользователю {user_id}.")
        except Exception:
            bot.reply_to(message, "Ошибка: Убедитесь, что вы ввели команду в правильном формате:\n/give <user_id> <amount>")
    else:
        bot.reply_to(message, "У вас нет прав для выполнения этой команды.")

@bot.message_handler(commands=['start'])
def start_command(message):
    user_id = message.chat.id
    db.add_user(user_id)
    balance = db.get_balance(user_id)
    
    reply_text = f"Привет! Твой баланс: {balance:.2f} $"
    bot.reply_to(message, reply_text)

    show_games(message)

@bot.message_handler(func=lambda message: message.text in ["Краш", "Кости", "Рулетка", "50/50", "Растущие шансы", "Монета", "Слот машины"])
def game_choice(message):
    global current_game
    current_game[message.chat.id] = message.text
    bot.reply_to(message, f"Вы выбрали игру: {message.text}. Введите вашу ставку:")

@bot.message_handler(func=lambda message: message.chat.id in current_game)
def handle_bet(message):
    user_id = message.chat.id
    selected_game = current_game[user_id]

    try:
        bet = float(message.text)  # Считываем и преобразуем ставку
    except ValueError:
        bot.reply_to(message, "Пожалуйста, введите корректную сумму ставки.")
        return

    balance = db.get_balance(user_id)

    if bet > balance:
        bot.reply_to(message, "Недостаточно средств для этой ставки.")
        return

    current_bet[user_id] = bet

    if selected_game == "Краш":
        play_crash(message, bet)
    elif selected_game == "Кости":
        ask_dice_choice(message, bet)
    elif selected_game == "Рулетка":
        ask_roulette_choice(message, bet)
    elif selected_game == "50/50":
        ask_fifty_fifty_choice(message, bet)
    elif selected_game == "Растущие шансы":
        ask_increasing_odds_choice(message, bet)
    elif selected_game == "Монета":
        ask_coin_flip_choice(message, bet)
    elif selected_game == "Слот машины":
        play_slot_machine(message, bet)

def show_games(message):
    reply_text = "Доступные игры: \nКраш\nКости\nРулетка\n50/50\nРастущие шансы\nМонета\nСлот машины\nВведите название игры, чтобы начать."
    bot.send_message(message.chat.id, reply_text)

def play_crash(message, bet):
    user_id = message.chat.id
    bot.send_message(user_id, "Стартуем игру 'Краш'...")
    
    crash_coefficient = random.uniform(1.0, 5.0)
    user_stop = random.uniform(1.0, 5.0)  # Случайный коэффициент пользователя

    if user_stop < crash_coefficient:
        winnings = bet * crash_coefficient
        db.update_balance(user_id, winnings - bet)
        db.add_game_history(user_id, "Краш", bet, winnings)
        bot.send_message(user_id, f"Вы выиграли {winnings:.2f} $. Коэффициент: {user_stop:.2f}!")
    else:
        db.update_balance(user_id, -bet)
        db.add_game_history(user_id, "Краш", bet, 0)
        bot.send_message(user_id, f"Вы проиграли. Коэффициент: {user_stop:.2f}. Попробуйте снова!")

def ask_dice_choice(message, bet):
    keyboard = [
        [types.InlineKeyboardButton("Чет", callback_data=f"dice_even")],
        [types.InlineKeyboardButton("Нечет", callback_data=f"dice_odd")]
    ]
    reply_markup = types.InlineKeyboardMarkup(keyboard)
    bot.send_message(message.chat.id, "Выберите: Чет или Нечет:", reply_markup=reply_markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("dice_"))
def handle_dice_choice(call):
    choice = call.data  # получаем выбор пользователя
    bet = current_bet[call.from_user.id]  # Получаем историю ставки
    user_id = call.message.chat.id

    # Анимация кубика
    bot.send_message(user_id, "Кидаем кубик...")
    time.sleep(1)
    dice_result = random.randint(1, 6)
    bot.send_message(user_id, f"Выпало: {dice_result}.")

    # Проверка на выигрыш или проигрыш
    if (choice == "dice_even" and dice_result % 2 == 0) or (choice == "dice_odd" and dice_result % 2 == 1):
        winnings = bet * 2
        db.update_balance(user_id, winnings - bet)
        db.add_game_history(user_id, "Кости", bet, winnings)
        bot.send_message(user_id, f"Вы выиграли {winnings:.2f} $!")
    else:
        db.update_balance(user_id, -bet)
        db.add_game_history(user_id, "Кости", bet, 0)
        bot.send_message(user_id, "Вы проиграли. Попробуйте снова!")

def ask_roulette_choice(message, bet):
    keyboard = [
        [types.InlineKeyboardButton("Чет", callback_data=f"roulette_even")],
        [types.InlineKeyboardButton("Нечет", callback_data=f"roulette_odd")],
        [types.InlineKeyboardButton("0", callback_data=f"roulette_zero")]
    ]
    reply_markup = types.InlineKeyboardMarkup(keyboard)
    bot.send_message(message.chat.id, "Выберите: Чет, Нечет или 0:", reply_markup=reply_markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("roulette_"))
def play_roulette(call):
    user_id = call.from_user.id
    bet = current_bet[user_id]  # Получаем ставку из текущего состояния
    result = random.randint(0, 36)  # Результат рулетки

    bot.send_message(user_id, f"Рулетка остановилась на: {result}.")

    choice = call.data
    if (choice == "roulette_even" and result % 2 == 0) or (choice == "roulette_odd" and result % 2 == 1) or (choice == "roulette_zero" and result == 0):
        winnings = bet * 2
        db.update_balance(user_id, winnings - bet)
        db.add_game_history(user_id, "Рулетка", bet, winnings)
        bot.send_message(user_id, f"Вы выиграли {winnings:.2f} $!")
    else:
        db.update_balance(user_id, -bet)
        db.add_game_history(user_id, "Рулетка", bet, 0)
        bot.send_message(user_id, "Вы проиграли. Попробуйте снова!")

def ask_fifty_fifty_choice(message, bet):
    keyboard = [
        [types.InlineKeyboardButton("Выиграть", callback_data=f"fifty_win")],
        [types.InlineKeyboardButton("Проиграть", callback_data=f"fifty_lose")]
    ]
    reply_markup = types.InlineKeyboardMarkup(keyboard)
    bot.send_message(message.chat.id, "Выберите: Выиграть или Проиграть:", reply_markup=reply_markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("fifty_"))
def play_fifty_fifty(call):
    user_id = call.from_user.id
    bet = current_bet[user_id]  # Получаем ставку из текущего состояния
    choice = call.data

    if choice == "fifty_win":
        winnings = bet * 2
        db.update_balance(user_id, winnings - bet)
        db.add_game_history(user_id, "50/50", bet, winnings)
        bot.send_message(user_id, f"Вы выиграли {winnings:.2f} $!")
    else:
        db.update_balance(user_id, -bet)
        db.add_game_history(user_id, "50/50", bet, 0)
        bot.send_message(user_id, "Вы проиграли. Попробуйте снова!")

def ask_increasing_odds_choice(message, bet):
    keyboard = [
        [types.InlineKeyboardButton("Рискнуть", callback_data=f"increasing_risk")],
        [types.InlineKeyboardButton("Умеренность", callback_data=f"increasing_safe")]
    ]
    reply_markup = types.InlineKeyboardMarkup(keyboard)
    bot.send_message(message.chat.id, "Выберите: Рискнуть или Умеренность:", reply_markup=reply_markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("increasing_"))
def play_increasing_odds(call):
    user_id = call.from_user.id
    bet = current_bet[user_id]  # Получаем ставку из текущего состояния
    choice = call.data

    odds = random.uniform(1.0, 10.0)
    success = (choice == "increasing_risk" and random.random() < (1.0 / odds)) or (choice == "increasing_safe" and random.random() >= (1.0 / odds))

    if success:
        winnings = bet * odds
        db.update_balance(user_id, winnings - bet)
        db.add_game_history(user_id, "Растущие шансы", bet, winnings)
        bot.send_message(user_id, f"Вы выиграли {winnings:.2f} $. Шанс был {odds:.2f}.")
    else:
        db.update_balance(user_id, -bet)
        db.add_game_history(user_id, "Растущие шансы", bet, 0)
        bot.send_message(user_id, "Вы проиграли. Попробуйте снова!")

def ask_coin_flip_choice(message, bet):
    keyboard = [
        [types.InlineKeyboardButton("Орел", callback_data=f"coin_heads")],
        [types.InlineKeyboardButton("Решка", callback_data=f"coin_tails")]
    ]
    reply_markup = types.InlineKeyboardMarkup(keyboard)
    bot.send_message(message.chat.id, "Выберите: Орел или Решка:", reply_markup=reply_markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("coin_"))
def play_coin_flip(call):
    user_id = call.from_user.id
    bet = current_bet[user_id]  # Получаем ставку из текущего состояния
    choice = call.data

    result = random.choice(["Орел", "Решка"])
    bot.send_message(user_id, f"Выпало: {result}.")

    if (choice == "coin_heads" and result == "Орел") or (choice == "coin_tails" and result == "Решка"):
        winnings = bet * 2
        db.update_balance(user_id, winnings - bet)
        db.add_game_history(user_id, "Монета", bet, winnings)
        bot.send_message(user_id, f"Вы выиграли {winnings:.2f} $!")
    else:
        db.update_balance(user_id, -bet)
        db.add_game_history(user_id, "Монета", bet, 0)
        bot.send_message(user_id, "Вы проиграли. Попробуйте снова!")

def play_slot_machine(message, bet):
    user_id = message.chat.id
    bot.send_message(user_id, "Крутим слот-машину... 🎰")
    time.sleep(2)  # Эффект ожидания

    slot_result = [random.choice(["🍒", "🍋", "🍉", "⭐", "💰"]) for _ in range(3)]
    winnings = bet * 10 if slot_result.count(slot_result[0]) == 3 else 0

    if winnings > 0:
        db.update_balance(user_id, winnings - bet)
        db.add_game_history(user_id, "Слот машины", bet, winnings)
        bot.send_message(user_id, f"Вы выиграли {winnings:.2f} $. Результат: {' '.join(slot_result)}.")
    else:
        db.update_balance(user_id, -bet)
        db.add_game_history(user_id, "Слот машины", bet, 0)
        bot.send_message(user_id, f"Вы проиграли. Результат: {' '.join(slot_result)}.")

# Запуск бота
if __name__ == "__main__":
    while True:
        try:
            bot.polling()  # Без таймаутов
        except Exception as e:
            print(f"Ошибка: {e}")
            time.sleep(15)  # Подождите немного перед повторной попыткой