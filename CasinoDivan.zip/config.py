BOT_TOKEN = 'ТокенБота'
ADMIN_ID = 'АйдиТелеграмАдмина'
DATABASE_NAME = 'wellchair-casino.db' 